/**
 * @file student.c
 * @author Sharmin Ahmed
 * @brief File contains functions that pertain to courses that students take, and ways to access or change the courses
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"


/**
 * @brief Takes a student and a grade and adds that grade to the student record
 * Checks whether or not the number of grades stored is 1 or more.
 * 
 * If 1, then it will create a dynamically allocated array to store the grade
 * If more then it will reallocate the array to include size for the extra grade
 * It will then add the grade to the array. 
 *
 * 
 * @param student 
 * @param grade 
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Returns the average of the students grades
 * 
 * For loop, looping through the number of grades there are and each time adds that grade to a variable called total
 * 
 * Returns a double the total divided by the number of grades there are which is the average.
 * 
 * @param student 
 * @return total / ((double) student->num_grades) (average grade of students courses)
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints information related to the student
 * Prints the name, ID, grades and average of the student
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Function that generate a random student
 * 
 * Uses a list of first and last names, and randomly selects a first and last name, and then adds random grades for the
 * student, then returns that new student.
 * 
 * @param grades 
 * @return new_student (the struct of the new student created)
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}