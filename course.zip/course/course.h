#include "student.h"
#include <stdbool.h>

/**
 * @brief Structure for a course
 * Structure for a course that contains its name, course code, array of students, and number of total students.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


