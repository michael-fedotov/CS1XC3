/**
 * @brief Structure representing a student
 * Contains members that include the first name, last name, id, array for grades
 * and number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Takes a student and a grade and adds that grade to the student record
 * Checks whether or not the number of grades stored is 1 or more.
 * 
 * If 1, then it will create a dynamically allocated array to store the grade
 * If more then it will reallocate the array to include size for the extra grade
 * It will then add the grade to the array. 
 *
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);
/**
 * @brief Returns the average of the students grades
 * 
 * For loop, looping through the number of grades there are and each time adds that grade to a variable called total
 * 
 * Returns a double the total divided by the number of grades there are which is the average.
 * 
 * @param student 
 * @return total / ((double) student->num_grades) (average grade of students courses)
 */
double average(Student *student);
/**
 * @brief Prints information related to the student
 * Prints the name, ID, grades and average of the student
 * 
 * @param student 
 */
void print_student(Student *student);
/**
 * @brief Function that generate a random student
 * 
 * Uses a list of first and last names, and randomly selects a first and last name, and then adds random grades for the
 * student, then returns that new student.
 * 
 * @param grades 
 * @return new_student (the struct of the new student created)
 */
Student* generate_random_student(int grades); 
