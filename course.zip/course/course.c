/**
 * @file course.c
 * @author Sharmin Ahmed
 * @brief File contains functions that pertain to courses that students take, and ways to access or change the courses
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>





/**
 * @brief Enrolls a student into a course
 * 
 * Takes in input for pointers to a course and student, then checks if there is only 1 student in the course, then it will
 * create a dynamic array of size 1, otherwise it will reallocate the dynamic array created to resize to 1 more space, then it
 * will add that new student
 * @param *course 
 * @param *student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}


/**
 * @brief Function used to print the course
 * Takes in input for the course and then prints the course name, code, total number of students and the students.
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Function returns the top student
 * Uses a for loop to search through the list of the students in the course provided as a parameter, at every stage it has counters
 * set up to keep track of the maximum average and the student that achieved it. At the end it will return that top student.
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns an array with the students who are passing the course
 * 
 * Takes in as an input a pointer to a course, and an array of students that are passing.
 * First it loops through and finds the number of students passing.
 * Then it creates a dynamic array of the size of the number of students passing.
 * Then it loops through the list and adds students who are passing (grade >= 50) to a dynamic array called passing.
 * Then it returns that array.
 * 
 * 
 * @param *course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}