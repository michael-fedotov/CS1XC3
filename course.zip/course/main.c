/**
 * @file main.c
 * @author Sharmin Ahmed
 * @brief File containing the main function
 * 
 * Main function creates a new course called MATH 101, enrolls students into it, selects the top student, and then generates
 * a list of students that are passing.
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));



  // Dynamic array used to store the course MATH101 that is of struct Course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // 
  //  * For loop used to add randoms students into the course MATH101
  //  * Uses the function enroll_student, that takes input of MATH101 and the random student generated
  //  * and adds them into the MATH101 struct.
  // 
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //  * Creating a pointer of type student that points to the top student of the course MATH101 which is the return value of the function
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //  * Creating a struct student which holds all of the students that are passing MATH101 and storing the number into the pointer
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}